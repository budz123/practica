﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proizvodctvennay_Practika.Models
{
    internal class Material
    {
        public int ID_материала { get; set; }
        public string Наименование { get; set; }
        public string Марка { get; set; }
        public string ГОСТ_или_ТУ { get; set; }
        public string Единица_измерения { get; set; }
    }
}
