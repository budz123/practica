﻿using Proizvodctvennay_Practika.Database.Repositories;
using Proizvodctvennay_Practika.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proizvodctvennay_Practika.Forms
{
    public partial class DetailsForm : Form
    {
        private DataGridView dataGridView;
        private ComboBox cmbFilterMaterial;
        private TextBox txtSearchDrawing;
        private Button btnSearch, btnAdd, btnEdit, btnDelete, btnRefresh;
        private DataTable dt;

        public DetailsForm()
        {
            InitializeComponents();
            LoadMaterialsFilter();
            LoadData();
        }

        private void InitializeComponents()
        {
            this.dataGridView = new DataGridView();
            this.btnAdd = new Button();
            this.btnEdit = new Button();
            this.btnDelete = new Button();
            this.btnRefresh = new Button();
            this.cmbFilterMaterial = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 200 };
            this.txtSearchDrawing = new TextBox { Width = 150 };
            this.btnSearch = new Button { Text = "Найти" };

            FlowLayoutPanel filterPanel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40, Padding = new Padding(5) };
            filterPanel.Controls.Add(new Label { Text = "Материал:", TextAlign = ContentAlignment.MiddleLeft });
            filterPanel.Controls.Add(cmbFilterMaterial);
            filterPanel.Controls.Add(new Label { Text = "Номер чертежа:" });
            filterPanel.Controls.Add(txtSearchDrawing);
            filterPanel.Controls.Add(btnSearch);

            this.dataGridView.Dock = DockStyle.Fill;
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            this.btnAdd.Text = "Добавить";
            this.btnEdit.Text = "Редактировать";
            this.btnDelete.Text = "Удалить";
            this.btnRefresh.Text = "Обновить";

            FlowLayoutPanel btnPanel = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 40 };
            btnPanel.Controls.AddRange(new Control[] { btnAdd, btnEdit, btnDelete, btnRefresh });

            this.Controls.Add(dataGridView);
            this.Controls.Add(btnPanel);
            this.Controls.Add(filterPanel);
            this.Text = "Детали";
            this.Size = new System.Drawing.Size(1000, 600);

            this.btnAdd.Click += BtnAdd_Click;
            this.btnEdit.Click += BtnEdit_Click;
            this.btnDelete.Click += BtnDelete_Click;
            this.btnRefresh.Click += (s, e) => LoadData();
            this.btnSearch.Click += (s, e) => LoadData();
            this.cmbFilterMaterial.SelectedIndexChanged += (s, e) => LoadData();
        }

        private void LoadMaterialsFilter()
        {
            DataTable mats = MaterialRepository.GetAllAsDataTable();
            DataRow row = mats.NewRow();
            row["Наименование"] = "Все";
            row["ID_материала"] = 0;
            mats.Rows.InsertAt(row, 0);
            cmbFilterMaterial.DataSource = mats;
            cmbFilterMaterial.DisplayMember = "Наименование";
            cmbFilterMaterial.ValueMember = "ID_материала";
        }

        private void LoadData()
        {
            string query = @"SELECT Д.ID_детали, Д.Номер_чертежа, Д.Наименование, Д.Масса_кг, 
                                    М.Наименование AS Материал, М.Марка
                             FROM Детали Д
                             LEFT JOIN Материалы М ON Д.ID_материала = М.ID_материала
                             WHERE 1=1";
            int filterMaterial = Convert.ToInt32(cmbFilterMaterial.SelectedValue);
            if (filterMaterial != 0)
                query += $" AND Д.ID_материала = {filterMaterial}";
            if (!string.IsNullOrWhiteSpace(txtSearchDrawing.Text))
                query += $" AND Д.Номер_чертежа LIKE '%{txtSearchDrawing.Text}%'";

            query += " ORDER BY Д.Номер_чертежа";
            dt = DatabaseHelper.ExecuteQuery(query);
            dataGridView.DataSource = dt;
            if (dataGridView.Columns.Contains("ID_детали"))
                dataGridView.Columns["ID_детали"].Visible = false;
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            var dialog = new DetailEditDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                DetailRepository.Add(dialog.DrawingNumber, dialog.Name, dialog.Mass, dialog.MaterialId);
                LoadData();
            }
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView.CurrentRow == null) return;
            int id = Convert.ToInt32(dataGridView.CurrentRow.Cells["ID_детали"].Value);
            string drawing = dataGridView.CurrentRow.Cells["Номер_чертежа"].Value.ToString();
            string name = dataGridView.CurrentRow.Cells["Наименование"].Value.ToString();
            decimal mass = Convert.ToDecimal(dataGridView.CurrentRow.Cells["Масса_кг"].Value);
            // материал нужно подгрузить из скрытого ID_материала? У нас в запросе нет ID_материала. Исправим запрос.
            // Для простоты пока сделаем диалог без предзаполнения материала.
            var dialog = new DetailEditDialog(drawing, name, mass);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                DetailRepository.Update(id, dialog.DrawingNumber, dialog.Name, dialog.Mass, dialog.MaterialId);
                LoadData();
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView.CurrentRow == null) return;
            int id = Convert.ToInt32(dataGridView.CurrentRow.Cells["ID_детали"].Value);
            if (MessageBox.Show("Удалить деталь?", "Подтверждение", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    DetailRepository.Delete(id);
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }

    // Диалог для детали
    public class DetailEditDialog : Form
    {
        public string DrawingNumber { get; private set; }
        public string Name { get; private set; }
        public decimal Mass { get; private set; }
        public int MaterialId { get; private set; }

        private TextBox txtDrawing, txtName, txtMass;
        private ComboBox cmbMaterial;
        private Button btnOk, btnCancel;

        public DetailEditDialog(string drawing = "", string name = "", decimal mass = 0)
        {
            InitializeComponent();
            txtDrawing.Text = drawing;
            txtName.Text = name;
            txtMass.Text = mass.ToString();
            LoadMaterials();
        }

        private void InitializeComponent()
        {
            this.Text = "Деталь";
            this.Size = new System.Drawing.Size(450, 250);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;

            TableLayoutPanel tlp = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 5, Padding = new Padding(10) };
            tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70F));

            tlp.Controls.Add(new Label { Text = "Номер чертежа:", TextAlign = ContentAlignment.MiddleRight }, 0, 0);
            txtDrawing = new TextBox { Dock = DockStyle.Fill };
            tlp.Controls.Add(txtDrawing, 1, 0);

            tlp.Controls.Add(new Label { Text = "Наименование:", TextAlign = ContentAlignment.MiddleRight }, 0, 1);
            txtName = new TextBox { Dock = DockStyle.Fill };
            tlp.Controls.Add(txtName, 1, 1);

            tlp.Controls.Add(new Label { Text = "Масса (кг):", TextAlign = ContentAlignment.MiddleRight }, 0, 2);
            txtMass = new TextBox { Dock = DockStyle.Fill };
            tlp.Controls.Add(txtMass, 1, 2);

            tlp.Controls.Add(new Label { Text = "Материал:", TextAlign = ContentAlignment.MiddleRight }, 0, 3);
            cmbMaterial = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill };
            tlp.Controls.Add(cmbMaterial, 1, 3);

            FlowLayoutPanel btnPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
            btnOk = new Button { Text = "OK", DialogResult = DialogResult.OK, Width = 80 };
            btnCancel = new Button { Text = "Отмена", DialogResult = DialogResult.Cancel, Width = 80 };
            btnPanel.Controls.Add(btnOk);
            btnPanel.Controls.Add(btnCancel);
            tlp.Controls.Add(btnPanel, 1, 4);

            this.Controls.Add(tlp);
            this.AcceptButton = btnOk;
            this.CancelButton = btnCancel;

            btnOk.Click += (s, e) =>
            {
                DrawingNumber = txtDrawing.Text.Trim();
                Name = txtName.Text.Trim();
                if (!decimal.TryParse(txtMass.Text, out decimal m))
                {
                    MessageBox.Show("Некорректная масса");
                    this.DialogResult = DialogResult.None;
                    return;
                }
                Mass = m;
                MaterialId = (int)cmbMaterial.SelectedValue;
            };
        }

        private void LoadMaterials()
        {
            DataTable dt = MaterialRepository.GetAllAsDataTable();
            cmbMaterial.DataSource = dt;
            cmbMaterial.DisplayMember = "Наименование";
            cmbMaterial.ValueMember = "ID_материала";
        }
    }
}
