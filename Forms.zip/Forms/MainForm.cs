﻿using Proizvodctvennay_Practika.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proizvodctvennay_Practika
{
    public partial class MainForm : Form
    {
            public MainForm()
            {
                InitializeComponents();
                IsMdiContainer = true;
                WindowState = FormWindowState.Maximized;
            }

            private void InitializeComponents()
            {
            MenuStrip menu = new MenuStrip();
            var справочники = new ToolStripMenuItem("Справочники");
            var материалы = new ToolStripMenuItem("Материалы");
            var детали = new ToolStripMenuItem("Детали");
            var операции = new ToolStripMenuItem("Операции");
            var сборочныеЕдиницы = new ToolStripMenuItem("Сборочные единицы");
            var изделия = new ToolStripMenuItem("Изделия");

            var производство = new ToolStripMenuItem("Производство");
            var маршрутныеЛисты = new ToolStripMenuItem("Маршрутные листы");
            var составИзделия = new ToolStripMenuItem("Состав изделия");

            var склад = new ToolStripMenuItem("Склад");
            var складОстатки = new ToolStripMenuItem("Остатки деталей");

            материалы.Click += (s, e) => OpenForm<MaterialsForm>();
            детали.Click += (s, e) => OpenForm<DetailsForm>();
            операции.Click += (s, e) => OpenForm<OperationsForm>();
            сборочныеЕдиницы.Click += (s, e) => OpenForm<AssemblyUnitsForm>();
            изделия.Click += (s, e) => OpenForm<ProductsForm>();
            маршрутныеЛисты.Click += (s, e) => OpenForm<RouteSheetsForm>();
            составИзделия.Click += (s, e) => OpenForm<ProductStructureForm>();
            складОстатки.Click += (s, e) => OpenForm<StockForm>();

            справочники.DropDownItems.AddRange(new ToolStripItem[] { материалы, детали, операции, сборочныеЕдиницы, изделия });
            производство.DropDownItems.AddRange(new ToolStripItem[] { маршрутныеЛисты, составИзделия });
            склад.DropDownItems.Add(складОстатки);

            menu.Items.AddRange(new ToolStripItem[] { справочники, производство, склад });
            this.MainMenuStrip = menu;
            this.Controls.Add(menu);
            this.Text = "Управление номенклатурой и производством - АО АтоммашЭкспорт";
        }

        private void OpenForm<T>() where T : Form, new()
        {
            foreach (Form f in MdiChildren)
            {
                if (f is T)
                {
                    f.Activate();
                    return;
                }
            }
            T form = new T();
            form.MdiParent = this;
            form.WindowState = FormWindowState.Maximized;
            form.Show();
        }
    }
}
