﻿using Proizvodctvennay_Practika.Database.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proizvodctvennay_Practika.Forms
{
    public partial class MaterialsForm : Form
    {
        // Объявляем элементы управления как поля класса
        private DataGridView dataGridView;
        private Button btnAdd, btnEdit, btnDelete, btnRefresh;
        private DataTable dt;

        public MaterialsForm()
        {
            InitializeComponents(); // теперь этот метод существует один раз
            LoadData();
        }

        private void InitializeComponents()
        {
            this.dataGridView = new DataGridView();
            this.btnAdd = new Button();
            this.btnEdit = new Button();
            this.btnDelete = new Button();
            this.btnRefresh = new Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();

            // dataGridView
            this.dataGridView.Dock = DockStyle.Fill;
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView.MultiSelect = false;

            // кнопки
            this.btnAdd.Text = "Добавить";
            this.btnEdit.Text = "Редактировать";
            this.btnDelete.Text = "Удалить";
            this.btnRefresh.Text = "Обновить";

            // панель внизу
            FlowLayoutPanel panel = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 40 };
            panel.Controls.AddRange(new Control[] { btnAdd, btnEdit, btnDelete, btnRefresh });

            this.Controls.Add(dataGridView);
            this.Controls.Add(panel);
            this.Text = "Справочник материалов";
            this.Size = new System.Drawing.Size(800, 500);

            // подписки на события
            this.btnAdd.Click += BtnAdd_Click;
            this.btnEdit.Click += BtnEdit_Click;
            this.btnDelete.Click += BtnDelete_Click;
            this.btnRefresh.Click += (s, e) => LoadData();

            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout();
        }

        private void LoadData()
        {
            dt = MaterialRepository.GetAllAsDataTable();
            dataGridView.DataSource = dt;
            if (dataGridView.Columns.Contains("ID_материала"))
                dataGridView.Columns["ID_материала"].Visible = false;
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            var dialog = new MaterialEditDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                MaterialRepository.Add(dialog.MaterialName, dialog.Mark, dialog.Gost, dialog.Unit);
                LoadData();
            }
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView.CurrentRow == null) return;
            int id = Convert.ToInt32(dataGridView.CurrentRow.Cells["ID_материала"].Value);
            string name = dataGridView.CurrentRow.Cells["Наименование"].Value.ToString();
            string mark = dataGridView.CurrentRow.Cells["Марка"].Value.ToString();
            string gost = dataGridView.CurrentRow.Cells["ГОСТ_или_ТУ"].Value.ToString();
            string unit = dataGridView.CurrentRow.Cells["Единица_измерения"].Value.ToString();

            var dialog = new MaterialEditDialog(name, mark, gost, unit);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                MaterialRepository.Update(id, dialog.MaterialName, dialog.Mark, dialog.Gost, dialog.Unit);
                LoadData();
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView.CurrentRow == null) return;
            int id = Convert.ToInt32(dataGridView.CurrentRow.Cells["ID_материала"].Value);
            if (MessageBox.Show("Удалить выбранный материал?", "Подтверждение", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    MaterialRepository.Delete(id);
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }

    // Диалог для ввода/редактирования материала
    public class MaterialEditDialog : Form
    {
        public string MaterialName { get; private set; }
        public string Mark { get; private set; }
        public string Gost { get; private set; }
        public string Unit { get; private set; }

        private TextBox txtName, txtMark, txtGost, txtUnit;
        private Button btnOk, btnCancel;

        public MaterialEditDialog(string name = "", string mark = "", string gost = "", string unit = "")
        {
            InitializeComponent();
            txtName.Text = name;
            txtMark.Text = mark;
            txtGost.Text = gost;
            txtUnit.Text = unit;
        }

        private void InitializeComponent()
        {
            this.Text = "Материал";
            this.Size = new System.Drawing.Size(400, 220);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;

            TableLayoutPanel tlp = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 5, Padding = new Padding(10) };
            tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70F));

            tlp.Controls.Add(new Label { Text = "Наименование:", TextAlign = ContentAlignment.MiddleRight }, 0, 0);
            txtName = new TextBox { Dock = DockStyle.Fill };
            tlp.Controls.Add(txtName, 1, 0);

            tlp.Controls.Add(new Label { Text = "Марка:", TextAlign = ContentAlignment.MiddleRight }, 0, 1);
            txtMark = new TextBox { Dock = DockStyle.Fill };
            tlp.Controls.Add(txtMark, 1, 1);

            tlp.Controls.Add(new Label { Text = "ГОСТ/ТУ:", TextAlign = ContentAlignment.MiddleRight }, 0, 2);
            txtGost = new TextBox { Dock = DockStyle.Fill };
            tlp.Controls.Add(txtGost, 1, 2);

            tlp.Controls.Add(new Label { Text = "Ед. изм.:", TextAlign = ContentAlignment.MiddleRight }, 0, 3);
            txtUnit = new TextBox { Dock = DockStyle.Fill };
            tlp.Controls.Add(txtUnit, 1, 3);

            FlowLayoutPanel btnPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
            btnOk = new Button { Text = "OK", DialogResult = DialogResult.OK, Width = 80 };
            btnCancel = new Button { Text = "Отмена", DialogResult = DialogResult.Cancel, Width = 80 };
            btnPanel.Controls.Add(btnOk);
            btnPanel.Controls.Add(btnCancel);
            tlp.Controls.Add(btnPanel, 1, 4);

            this.Controls.Add(tlp);
            this.AcceptButton = btnOk;
            this.CancelButton = btnCancel;
        }
    }
}

