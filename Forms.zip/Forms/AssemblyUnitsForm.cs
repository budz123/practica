﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proizvodctvennay_Practika.Forms
{
    public partial class AssemblyUnitsForm : Form
    {
        public AssemblyUnitsForm() { InitializeComponents(); }
        private void InitializeComponents() { this.Text = "Сборочные единицы"; this.Size = new System.Drawing.Size(800, 500); }
    }
}
