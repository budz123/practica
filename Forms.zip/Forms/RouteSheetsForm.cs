﻿using MySql.Data.MySqlClient;
using Proizvodctvennay_Practika.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proizvodctvennay_Practika.Forms
{
    public partial class RouteSheetsForm : Form
    {
        private DataGridView dgvDetails;
        private DataGridView dgvOperations;
        private ComboBox cmbRouteSheet; // если нужно выбрать маршрут
        private int currentDetailId = -1;

        public RouteSheetsForm()
        {
            InitializeComponents();
            LoadDetails();
        }

        private void InitializeComponents()
        {
            SplitContainer split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Horizontal };
            // ... (создание панелей)
            dgvDetails = new DataGridView { Dock = DockStyle.Fill, SelectionMode = DataGridViewSelectionMode.FullRowSelect };
            dgvOperations = new DataGridView { Dock = DockStyle.Fill, AllowUserToAddRows = false };
            split.Panel1.Controls.Add(dgvDetails);
            split.Panel2.Controls.Add(dgvOperations);
            this.Controls.Add(split);
            // Кнопки: Добавить операцию, Удалить операцию, Вверх/Вниз
            dgvDetails.SelectionChanged += (s, e) => LoadRouteForDetail();
        }

        private void LoadDetails()
        {
            DataTable dt = DatabaseHelper.ExecuteQuery("SELECT ID_детали, Номер_чертежа, Наименование FROM Детали ORDER BY Номер_чертежа");
            dgvDetails.DataSource = dt;
            dgvDetails.Columns["ID_детали"].Visible = false;
        }

        private void LoadRouteForDetail()
        {
            if (dgvDetails.CurrentRow == null) return;
            currentDetailId = Convert.ToInt32(dgvDetails.CurrentRow.Cells["ID_детали"].Value);
            string query = @"SELECT О.Код_операции, О.Наименование_операции, О.Разряд_работ, О.Норма_времени_мин, СМ.Номер_шага
                         FROM Состав_маршрута СМ
                         JOIN Маршрутные_листы МЛ ON СМ.ID_маршрута = МЛ.ID_маршрута
                         JOIN Операции О ON СМ.ID_операции = О.ID_операции
                         WHERE МЛ.ID_детали = @detailId
                         ORDER BY СМ.Номер_шага";
            var p = new MySqlParameter("@detailId", currentDetailId);
            DataTable dt = DatabaseHelper.ExecuteQuery(query, new[] { p });
            dgvOperations.DataSource = dt;
            // Добавить столбец "Номер шага" и т.д.
        }
    }
}
