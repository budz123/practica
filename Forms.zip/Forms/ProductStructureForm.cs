﻿using MySql.Data.MySqlClient;
using Proizvodctvennay_Practika.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proizvodctvennay_Practika.Forms
{
    public partial class ProductStructureForm : Form
    {
        private TreeView treeView;
        private ComboBox cmbProducts;
        private Button btnRefresh;

        public ProductStructureForm()
        {
            InitializeComponent();
            LoadProducts();
            cmbProducts.SelectedIndexChanged += (s, e) => LoadStructure();
        }

        private void LoadProducts()
        {
            DataTable dt = DatabaseHelper.ExecuteQuery("SELECT ID_изделия, Номер_изделия, Наименование FROM Изделия");
            cmbProducts.DataSource = dt;
            cmbProducts.DisplayMember = "Номер_изделия";
            cmbProducts.ValueMember = "ID_изделия";
        }

        private void LoadStructure()
        {
            treeView.Nodes.Clear();
            int productId = Convert.ToInt32(cmbProducts.SelectedValue);
            TreeNode root = new TreeNode($"Изделие {cmbProducts.Text}");
            LoadComponents(productId, root);
            treeView.Nodes.Add(root);
            treeView.ExpandAll();
        }

        private void LoadComponents(int parentId, TreeNode parentNode, bool isProduct = true)
        {
            string query = @"SELECT ID_состава, Тип_компонента, ID_компонента, Количество FROM Состав_изделия WHERE ID_изделия = @pid";
            var p = new MySqlParameter("@pid", parentId);
            DataTable dt = DatabaseHelper.ExecuteQuery(query, new[] { p });
            foreach (DataRow row in dt.Rows)
            {
                string type = row["Тип_компонента"].ToString();
                int compId = Convert.ToInt32(row["ID_компонента"]);
                int qty = Convert.ToInt32(row["Количество"]);
                string name = "";
                if (type == "Деталь")
                {
                    var r = DatabaseHelper.ExecuteQuery($"SELECT Номер_чертежа, Наименование FROM Детали WHERE ID_детали={compId}");
                    if (r.Rows.Count > 0)
                        name = $"{r.Rows[0]["Номер_чертежа"]} - {r.Rows[0]["Наименование"]}";
                }
                else
                {
                    var r = DatabaseHelper.ExecuteQuery($"SELECT Номер_сборочного_чертежа, Наименование FROM Сборочные_единицы WHERE ID_сб_ед={compId}");
                    if (r.Rows.Count > 0)
                        name = $"{r.Rows[0]["Номер_сборочного_чертежа"]} - {r.Rows[0]["Наименование"]}";
                }
                TreeNode node = new TreeNode($"{name} (x{qty})");
                parentNode.Nodes.Add(node);
                // Рекурсия для вложенных сборочных единиц – если они могут содержать другие компоненты, доработайте
            }
        }
    }
}
