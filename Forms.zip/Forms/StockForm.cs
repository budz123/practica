﻿using MySql.Data.MySqlClient;
using Proizvodctvennay_Practika.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proizvodctvennay_Practika.Forms
{
    public partial class StockForm : Form
    {
        private DataGridView dgvStock;
        private Button btnIncome, btnOutcome;

        public StockForm()
        {
            InitializeComponents();
            LoadStock();
        }

        private void InitializeComponents()
        {
            dgvStock = new DataGridView { Dock = DockStyle.Fill, AllowUserToAddRows = false };
            btnIncome = new Button { Text = "Приход", Width = 100 };
            btnOutcome = new Button { Text = "Расход", Width = 100 };
            FlowLayoutPanel panel = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 40 };
            panel.Controls.AddRange(new Control[] { btnIncome, btnOutcome });
            this.Controls.Add(dgvStock);
            this.Controls.Add(panel);
            this.Text = "Склад деталей";
            this.Size = new System.Drawing.Size(800, 500);

            btnIncome.Click += BtnIncome_Click;
            btnOutcome.Click += BtnOutcome_Click;
        }

        private void LoadStock()
        {
            string query = @"SELECT СД.ID_склада, Д.Номер_чертежа, Д.Наименование, СД.Количество_шт, СД.Ячейка
                             FROM Склад_деталей СД
                             JOIN Детали Д ON СД.ID_детали = Д.ID_детали";
            DataTable dt = DatabaseHelper.ExecuteQuery(query);
            dgvStock.DataSource = dt;
            if (dgvStock.Columns.Contains("ID_склада"))
                dgvStock.Columns["ID_склада"].Visible = false;
        }

        private void BtnIncome_Click(object sender, EventArgs e)
        {
            var dialog = new StockOperationDialog(true);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                string query = "INSERT INTO Склад_деталей (ID_детали, Количество_шт, Ячейка) VALUES (@detId, @qty, @cell) " +
                               "ON DUPLICATE KEY UPDATE Количество_шт = Количество_шт + @qty";
                var p = new MySqlParameter[]
                {
                    new MySqlParameter("@detId", dialog.DetailId),
                    new MySqlParameter("@qty", dialog.Quantity),
                    new MySqlParameter("@cell", dialog.Cell)
                };
                DatabaseHelper.ExecuteNonQuery(query, p);
                LoadStock();
            }
        }

        private void BtnOutcome_Click(object sender, EventArgs e)
        {
            var dialog = new StockOperationDialog(false);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                // Проверка, что на складе достаточно
                string check = "SELECT Количество_шт FROM Склад_деталей WHERE ID_детали=@detId";
                var p = new MySqlParameter("@detId", dialog.DetailId);
                object res = DatabaseHelper.ExecuteScalar(check, new[] { p });
                if (res == null || Convert.ToInt32(res) < dialog.Quantity)
                {
                    MessageBox.Show("Недостаточно деталей на складе", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                string query = "UPDATE Склад_деталей SET Количество_шт = Количество_шт - @qty WHERE ID_детали=@detId";
                DatabaseHelper.ExecuteNonQuery(query, new[] { p, new MySqlParameter("@qty", dialog.Quantity) });
                LoadStock();
            }
        }
    }

    public class StockOperationDialog : Form
    {
        public int DetailId { get; private set; }
        public int Quantity { get; private set; }
        public string Cell { get; private set; }

        private ComboBox cmbDetail;
        private TextBox txtQty, txtCell;
        private Button btnOk, btnCancel;
        private bool isIncome;

        public StockOperationDialog(bool income)
        {
            isIncome = income;
            InitializeComponent();
            LoadDetails();
            if (!income) txtCell.Enabled = false; // при расходе ячейка не нужна
        }

        private void InitializeComponent()
        {
            this.Text = isIncome ? "Приход деталей" : "Расход деталей";
            this.Size = new System.Drawing.Size(400, 200);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;

            TableLayoutPanel tlp = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 4, Padding = new Padding(10) };
            tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70F));

            tlp.Controls.Add(new Label { Text = "Деталь:", TextAlign = ContentAlignment.MiddleRight }, 0, 0);
            cmbDetail = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill };
            tlp.Controls.Add(cmbDetail, 1, 0);

            tlp.Controls.Add(new Label { Text = "Количество:", TextAlign = ContentAlignment.MiddleRight }, 0, 1);
            txtQty = new TextBox { Dock = DockStyle.Fill };
            tlp.Controls.Add(txtQty, 1, 1);

            if (isIncome)
            {
                tlp.Controls.Add(new Label { Text = "Ячейка:", TextAlign = ContentAlignment.MiddleRight }, 0, 2);
                txtCell = new TextBox { Dock = DockStyle.Fill };
                tlp.Controls.Add(txtCell, 1, 2);
            }

            FlowLayoutPanel btnPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
            btnOk = new Button { Text = "OK", DialogResult = DialogResult.OK, Width = 80 };
            btnCancel = new Button { Text = "Отмена", DialogResult = DialogResult.Cancel, Width = 80 };
            btnPanel.Controls.Add(btnOk);
            btnPanel.Controls.Add(btnCancel);
            tlp.Controls.Add(btnPanel, 1, isIncome ? 3 : 2);

            this.Controls.Add(tlp);
            this.AcceptButton = btnOk;
            this.CancelButton = btnCancel;

            btnOk.Click += (s, e) =>
            {
                DetailId = (int)cmbDetail.SelectedValue;
                if (!int.TryParse(txtQty.Text, out int qty) || qty <= 0)
                {
                    MessageBox.Show("Введите положительное количество");
                    this.DialogResult = DialogResult.None;
                    return;
                }
                Quantity = qty;
                Cell = txtCell?.Text ?? "";
            };
        }

        private void LoadDetails()
        {
            DataTable dt = DatabaseHelper.ExecuteQuery("SELECT ID_детали, Номер_чертежа, Наименование FROM Детали");
            cmbDetail.DataSource = dt;
            cmbDetail.DisplayMember = "Номер_чертежа";
            cmbDetail.ValueMember = "ID_детали";
        }
    }
}
