﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proizvodctvennay_Practika.Database.Repositories
{
    internal class MaterialRepository
    {
        public static DataTable GetAllAsDataTable()
        {
            string query = "SELECT ID_материала, Наименование, Марка, ГОСТ_или_ТУ, Единица_измерения FROM Материалы ORDER BY Наименование";
            return DatabaseHelper.ExecuteQuery(query);
        }

        public static void Add(string name, string mark, string gost, string unit)
        {
            string query = "INSERT INTO Материалы (Наименование, Марка, ГОСТ_или_ТУ, Единица_измерения) VALUES (@name, @mark, @gost, @unit)";
            var p = new MySqlParameter[]
            {
                new MySqlParameter("@name", name),
                new MySqlParameter("@mark", mark),
                new MySqlParameter("@gost", gost),
                new MySqlParameter("@unit", unit)
            };
            DatabaseHelper.ExecuteNonQuery(query, p);
        }

        public static void Update(int id, string name, string mark, string gost, string unit)
        {
            string query = "UPDATE Материалы SET Наименование=@name, Марка=@mark, ГОСТ_или_ТУ=@gost, Единица_измерения=@unit WHERE ID_материала=@id";
            var p = new MySqlParameter[]
            {
                new MySqlParameter("@id", id),
                new MySqlParameter("@name", name),
                new MySqlParameter("@mark", mark),
                new MySqlParameter("@gost", gost),
                new MySqlParameter("@unit", unit)
            };
            DatabaseHelper.ExecuteNonQuery(query, p);
        }

        public static void Delete(int id)
        {
            // Проверка, используется ли материал в деталях (внешний ключ)
            string check = "SELECT COUNT(*) FROM Детали WHERE ID_материала=@id";
            int count = Convert.ToInt32(DatabaseHelper.ExecuteScalar(check, new[] { new MySqlParameter("@id", id) }));
            if (count > 0)
                throw new Exception("Материал используется в деталях, удаление невозможно.");
            string query = "DELETE FROM Материалы WHERE ID_материала=@id";
            DatabaseHelper.ExecuteNonQuery(query, new[] { new MySqlParameter("@id", id) });
        }
    }
}
