﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proizvodctvennay_Practika.Database.Repositories
{
    internal class DetailRepository
    {
        public static void Add(string drawing, string name, decimal mass, int materialId)
        {
            string query = "INSERT INTO Детали (Номер_чертежа, Наименование, Масса_кг, ID_материала) VALUES (@draw, @name, @mass, @mat)";
            var p = new MySqlParameter[]
            {
                new MySqlParameter("@draw", drawing),
                new MySqlParameter("@name", name),
                new MySqlParameter("@mass", mass),
                new MySqlParameter("@mat", materialId)
            };
            DatabaseHelper.ExecuteNonQuery(query, p);
        }

        public static void Update(int id, string drawing, string name, decimal mass, int materialId)
        {
            string query = "UPDATE Детали SET Номер_чертежа=@draw, Наименование=@name, Масса_кг=@mass, ID_материала=@mat WHERE ID_детали=@id";
            var p = new MySqlParameter[]
            {
                new MySqlParameter("@id", id),
                new MySqlParameter("@draw", drawing),
                new MySqlParameter("@name", name),
                new MySqlParameter("@mass", mass),
                new MySqlParameter("@mat", materialId)
            };
            DatabaseHelper.ExecuteNonQuery(query, p);
        }

        public static void Delete(int id)
        {
            // Проверяем использование в маршрутных листах, составе изделия, складе
            string check = "SELECT COUNT(*) FROM Маршрутные_листы WHERE ID_детали=@id";
            int count = Convert.ToInt32(DatabaseHelper.ExecuteScalar(check, new[] { new MySqlParameter("@id", id) }));
            if (count > 0)
                throw new Exception("Деталь используется в маршрутных листах, удаление невозможно.");
            check = "SELECT COUNT(*) FROM Состав_изделия WHERE Тип_компонента='Деталь' AND ID_компонента=@id";
            count = Convert.ToInt32(DatabaseHelper.ExecuteScalar(check, new[] { new MySqlParameter("@id", id) }));
            if (count > 0)
                throw new Exception("Деталь входит в состав изделия, удаление невозможно.");
            check = "SELECT COUNT(*) FROM Склад_деталей WHERE ID_детали=@id";
            count = Convert.ToInt32(DatabaseHelper.ExecuteScalar(check, new[] { new MySqlParameter("@id", id) }));
            if (count > 0)
                throw new Exception("Деталь есть на складе, удаление невозможно.");

            string query = "DELETE FROM Детали WHERE ID_детали=@id";
            DatabaseHelper.ExecuteNonQuery(query, new[] { new MySqlParameter("@id", id) });
        }
    }
}
